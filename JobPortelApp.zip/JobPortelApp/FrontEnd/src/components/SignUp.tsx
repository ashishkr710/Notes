import React, { useState, useEffect } from 'react';
import { Formik, Form, Field, ErrorMessage, FormikHelpers } from 'formik';
import * as Yup from 'yup';
import { Button, Spinner } from 'react-bootstrap';
import axios from 'axios';

interface RegistrationValues {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    gender: string;
    role: string;
    hobbies: string[];
    profileImage: File | null;
    resume: File | null;
    agencyId: string;
}

interface Agency {
    id: string;
    name: string;
}

const SignUp: React.FC = () => {
    const [role, setrole] = useState('');
    const [agencies, setAgencies] = useState<Agency[]>([]);

    useEffect(() => {
        const fetchAgencies = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/agencies');
                setAgencies(response.data);
            } catch (error) {
                console.error('Failed to fetch agencies', error);
                setAgencies([]); // Ensure agencies is always an array
            }
        };

        fetchAgencies();
    }, []);

    const initialValues: RegistrationValues = {
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        gender: '',
        role: '',
        hobbies: [],
        profileImage: null,
        resume: null,
        agencyId: ''
    };

    const validationSchema = Yup.object({
        firstName: Yup.string().required('First name is required'),
        lastName: Yup.string().required('Last name is required'),
        email: Yup.string().email('Invalid email format').required('Email is required'),
        phone: Yup.string().matches(/^[0-9]+$/, 'Phone number must be numeric').required('Phone number is required'),
        gender: Yup.string().required('Gender is required'),
        role: Yup.string().required('User type is required'),
        profileImage: Yup.mixed().required('Profile image is required').test('fileFormat', 'Unsupported Format', value => value && ['image/jpeg', 'image/png'].includes((value as File).type)),
        // resume: Yup.mixed().when(['role'], (role: any, schema) => {
        //     if (role === '1') return Yup.mixed().required('Resume is required')
        //     return schema;
        // }),
        // agencyId: Yup.mixed().when(['role'], (role: any, schema) => {
        //     if (role === '1') return Yup.mixed().required('Associated Agency is required')
        //     return schema;
        // })
    });

    const handleSubmit = async (values: RegistrationValues, { setSubmitting }: FormikHelpers<RegistrationValues>) => {
        setSubmitting(true);
        try {
            const formData = new FormData();
            formData.append('firstName', values.firstName);
            formData.append('lastName', values.lastName);
            formData.append('email', values.email);
            formData.append('phone', values.phone);
            formData.append('gender', values.gender);
            formData.append('role', values.role);
            formData.append('hobbies', JSON.stringify(values.hobbies));
            if (values.profileImage) {
                formData.append('profileImg', values.profileImage);
            }
            if (values.resume) {
                formData.append('resume', values.resume);
            }
            formData.append('agencyId', values.agencyId);

            const response = await axios.post('http://localhost:5000/api/register', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            

            // Handle successful registration (e.g., show a success message, redirect to login page)
        } catch (error) {
            console.error(error);
            // Handle error
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
        >
            {({ setFieldValue, isSubmitting }) => (
                <Form>
                    <div>
                        <label>First Name:</label>
                        <Field type="text" name="firstName" />
                        <ErrorMessage name="firstName" component="div" />
                    </div>
                    <div>
                        <label>Last Name:</label>
                        <Field type="text" name="lastName" />
                        <ErrorMessage name="lastName" component="div" />
                    </div>
                    <div>
                        <label>Email:</label>
                        <Field type="email" name="email" />
                        <ErrorMessage name="email" component="div" />
                    </div>
                    <div>
                        <label>Phone:</label>
                        <Field type="text" name="phone" />
                        <ErrorMessage name="phone" component="div" />
                    </div>
                    <div>
                        <label>Gender:</label>
                        <Field type="radio" name="gender" value="Male" /> Male
                        <Field type="radio" name="gender" value="Female" /> Female
                        <ErrorMessage name="gender" component="div" />
                    </div>
                    <div>
                        <label>User Type:</label>
                        <Field as="select" name="role" onChange={(e: React.ChangeEvent<HTMLSelectElement>) => { setFieldValue('role', e.target.value); setrole(e.target.value); }}>
                            <option value="">Select</option>
                            <option value="Job Seeker">Job Seeker</option>
                            <option value="Agency">Agency</option>
                        </Field>
                        <ErrorMessage name="role" component="div" />
                    </div>
                    <div>
                        <label>Hobbies:</label>
                        <Field type="checkbox" name="hobbies" value="Sports" /> Sports
                        <Field type="checkbox" name="hobbies" value="Dance" /> Dance
                        <Field type="checkbox" name="hobbies" value="Reading" /> Reading
                        <Field type="checkbox" name="hobbies" value="Singing" /> Singing
                    </div>
                    <div>
                        <label>Profile Image:</label>
                        <input type="file" name="profileImage" accept=".png, .jpeg" onChange={(e) => setFieldValue('profileImage', e.currentTarget.files ? e.currentTarget.files[0] : null)} />
                        <ErrorMessage name="profileImage" component="div" />
                    </div>
                    {role === 'Job Seeker' && (
                        <>
                            <div>
                                <label>Resume:</label>
                                <input type="file" name="resume" accept=".docx, .pdf" onChange={(e) => setFieldValue('resume', e.currentTarget.files ? e.currentTarget.files[0] : null)} />
                                <ErrorMessage name="resume" component="div" />
                            </div>
                            <div>
                                <label>Agency:</label>
                                <Field as="select" name="agencyId">
                                    <option value="">Select</option>
                                    {Array.isArray(agencies) && agencies.map((agency) => (
                                        <option key={agency.id} value={agency.id}>
                                            {agency.name}
                                        </option>
                                    ))}
                                </Field>
                                <ErrorMessage name="agencyId" component="div" />
                            </div>
                        </>
                    )}
                    <Button type="submit" disabled={isSubmitting}>
                        {isSubmitting ? <Spinner animation="border" size="sm" /> : 'Register'}
                    </Button>
                </Form>
            )}
        </Formik>
    );
};

export default SignUp;
