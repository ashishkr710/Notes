import React from 'react';
import { Formik, Form, Field, ErrorMessage, FormikHelpers } from 'formik';
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import { Alert, Button, Spinner } from 'react-bootstrap';
import axios from 'axios';

interface LoginFormValues {
    email: string;
    password: string;
}

const Login: React.FC = () => {
    const navigate = useNavigate();
    const initialValues: LoginFormValues = {
        email: '',
        password: '',
    };

    const validationSchema = Yup.object().shape({
        email: Yup.string().email('Invalid email').required('email is required'),
        password: Yup.string().min(6, 'password must be at least 6 characters').required('password is required'),
    });

    const handleSubmit = async (values: LoginFormValues, { setSubmitting }: FormikHelpers<LoginFormValues>) => {
        setSubmitting(true);
        try {
            // Replace with actual login API call
            const response = await axios.post('http://localhost:5000/api/login', values);
            alert("login successfull");
            navigate('/dashboard');
            const data = response.data;
            console.log(data ,"data");
            // Save token or user data as needed
            // console.log(data.token,"helll world............................................");
            localStorage.setItem('token', data.token);
            
            // interface DecodedToken {
            //     // role: string;
            //     id:string
            //     // Add other properties as needed
            // }
            

            // Redirect based on user type
            // if (data.userType === 'Agency') {
            //     navigate('/agency-dashboard');
            // } else if (data.userType === 'Job Seeker') {
            //     navigate('/job-seeker-dashboard');
            // }
        } catch (error) {
            console.error(error);
            // Handle error
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
        >
            {({ isSubmitting, errors }) => (
                <Form>
                    <div>
                        <label>email:</label>
                        <Field type="email" name="email" />
                        <ErrorMessage name="email" component="div" />
                    </div>
                    <div>
                        <label>password:</label>
                        <Field type="password" name="password" />
                        <ErrorMessage name="password" component="div" />
                    </div>
                    {/* Handle general errors here if needed */}
                    <Button type="submit" disabled={isSubmitting}>
                        {isSubmitting ? <Spinner animation="border" size="sm" /> : 'Login'}
                    </Button>
                </Form>
            )}
        </Formik>
    );
};

export default Login;
