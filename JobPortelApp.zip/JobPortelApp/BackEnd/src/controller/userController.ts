
import { Request, Response, NextFunction } from 'express';

import User from '../model/User';
import bcrypt from 'bcrypt';
import { v4 as uuidv4 } from 'uuid';
import nodemailer from 'nodemailer';
import { Op } from 'sequelize';
import { Router } from 'express';
import multer from 'multer'; // For handling file uploads
import fs from 'fs';
import path from 'path';
import authMiddleware from '../middleware/authMiddleware'; // Middleware for authentication
import jwt from 'jsonwebtoken'; // Import jwt for login functionality

// Helper function to send email with login details
const sendLoginEmail = async (email: string, password: string) => {
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: process.env.EMAIL_USER, // Add your email in the environment variables
            pass: process.env.EMAIL_PASS, // Add your email password in environment variables
        },
    });

    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: email,
        subject: 'Your Login Details',
        text: `Your login details are as follows: \nEmail: ${email}\nPassword: ${password}`,
    };

    await transporter.sendMail(mailOptions);
};

// Register user
export const registerUser: any = async (req: Request, res: Response) => {
    try {
        const { firstName, lastName, email, phone, gender, role, hobbies, agencyId } = req.body;
        const profileImg = req.file ? req.file.filename : null;
        const resume = req.file && role == 2 ? req.file.filename : null; // Resume only if Job Seeker

        // Generate random password
        // const password = uuidv4();
        const password = "123456789";
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create a new user in the database
        const newUser = await User.create({
            firstName,
            lastName,
            email,
            phone,
            gender,
            role,
            hobbies: Array.isArray(hobbies) ? hobbies.join(',') : '', // Store hobbies as a comma-separated string
            profileImg,
            resume,
            agencyId: role == 2 ? agencyId : null, // Set agencyId only for Job Seekers
            password: hashedPassword,
        });

        // Send login details via email
        await sendLoginEmail(email, password);

        return res.status(201).json({
            message: 'User registered successfully! Login details have been sent to your email.',
            data: newUser,
        });
    } catch (error: any) {
        return res.status(500).json({
            message: 'Error registering user.',
            error: error.message,
        });
    }
};

// Ensure directories exist
const ensureDirectoryExistence = (dir: string) => {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
};

// Multer configuration for file uploads (profile image and resume)
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        let uploadPath = '';
        if (file.fieldname === 'profileImg') {
            uploadPath = 'uploads/profileImages';
        } else if (file.fieldname === 'resume') {
            uploadPath = 'uploads/resumes';
        }
        ensureDirectoryExistence(uploadPath);
        cb(null, uploadPath);
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    },
});

// File filter to accept only PNG, JPEG for profile images and .docx, .pdf for resumes
const fileFilter = (req: any, file: any, cb: any) => {
    if (file.fieldname === 'profileImg') {
        if (file.mimetype === 'image/png' || file.mimetype === 'image/jpeg') {
            cb(null, true);
        } else {
            cb(new Error('Invalid file type. Only PNG and JPEG are allowed for profile images.'));
        }
    } else if (file.fieldname === 'resume') {
        if (file.mimetype === 'application/pdf' || file.mimetype === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
            cb(null, true);
        } else {
            cb(new Error('Invalid file type. Only .docx and .pdf are allowed for resumes.'));
        }
    } else {
        cb(new Error('Invalid field name'), false);
    }
};

// Login user
export const loginUser = async (req: Request, res: Response): Promise<void> => {
    const { email, password } = req.body;

    try {
        // Check if user exists
        const user = await User.findOne({ where: { email } });
        if (!user) {
            res.status(401).json({ message: 'Invalid email or password' });
            return;
        }

        // Check if password is correct
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            res.status(401).json({ message: 'Invalid email or password' });
            return
        }

        // Generate JWT token
        const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, 'your_secret_key', { expiresIn: '1h' });

        res.status(200).json({ token });
        // alert("sucessfully login")
    } catch (error: any) {

        res.status(500).json({ message: 'Server error', error: error.message });

    }



};

export const getUser = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    const { id } = req.params;

    try {
        // Fetch user by ID
        const user = await User.findByPk(id, {
            attributes: { exclude: ['password'] } // Exclude password from the response
        });

        if (!user) {
            res.status(404).json({ message: 'User not found' });
            return;
        }

        res.status(200).json(user);
    } catch (error) {
        next(error);
    }
};
