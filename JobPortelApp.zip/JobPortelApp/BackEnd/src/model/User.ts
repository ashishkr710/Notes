import { Model, DataTypes, Optional } from 'sequelize';
import sequelize from '../config/database';

interface UserAttributes {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    password: string;
    gender: 'male' | 'female' | 'others';
    phone: number;
    role: number;
    hobbies: string;
    resume: string | null;
    profileImg: string | null;
    agencyId: number | null;
}

interface UserCreationAttributes extends Optional<UserAttributes, 'id' | 'resume' | 'profileImg' | 'agencyId'> {}

class User extends Model<UserAttributes, UserCreationAttributes> implements UserAttributes {
    public id!: number;
    public firstName!: string;
    public lastName!: string;
    public email!: string;
    public password!: string;
    public gender!: 'male' | 'female' | 'others';
    public phone!: number;
    public role!: number;
    public hobbies!: string;
    public resume!: string | null;
    public profileImg!: string | null;
    public agencyId!: number | null;
    public readonly createdAt!: Date;
    public readonly updatedAt!: Date;
}

User.init(
    {
        id: {
            type: DataTypes.INTEGER.UNSIGNED,
            autoIncrement: true,
            primaryKey: true,
        },
        firstName: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        lastName: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        email: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true,
            validate: {
                isEmail: true,
            },
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        gender: {
            type: DataTypes.ENUM('male', 'female', 'others'),
            allowNull: false,
        },
        phone: {
            type: DataTypes.BIGINT,
            allowNull: false,
            validate: {
                isNumeric: true,
            },
        },
        role: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                isIn: [[1, 2]], // 1 for Job Seeker, 2 for Agency
            },
        },
        hobbies: {
            type: DataTypes.STRING,
            allowNull: true, // Comma-separated string like "Sports, Dance"
        },
        resume: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        profileImg: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        agencyId: {
            type: DataTypes.INTEGER.UNSIGNED,
            allowNull: true,
        },
    },
    {
        sequelize,
        modelName: 'User',
        tableName: 'user',
        timestamps: true,
    }
);

// Define associations
User.hasMany(User, { foreignKey: 'agencyId', as: 'JobSeekers' });
User.belongsTo(User, { foreignKey: 'agencyId', as: 'Agency' });

export default User;
