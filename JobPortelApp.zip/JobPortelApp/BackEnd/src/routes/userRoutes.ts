import { Router } from 'express';
import multer from 'multer';
import { registerUser, loginUser, getUser } from '../controller/userController';
import authMiddleware from '../middleware/authMiddleware';

const router = Router();

// Multer configuration for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        if (file.fieldname === 'profileImg') {
            cb(null, 'uploads/profileImages');
        } else if (file.fieldname === 'resume') {
            cb(null, 'uploads/resumes');
        }
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    },
});

const fileFilter = (req: any, file: any, cb: any) => {
    if (file.fieldname === 'profileImg') {
        if (file.mimetype === 'image/png' || file.mimetype === 'image/jpeg') {
            cb(null, true);
        } else {
            cb(new Error('Invalid file type. Only PNG and JPEG are allowed for profile images.'));
        }
    } else if (file.fieldname === 'resume') {
        if (file.mimetype === 'application/pdf' || file.mimetype === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
            cb(null, true);
        } else {
            cb(new Error('Invalid file type. Only .docx and .pdf are allowed for resumes.'));
        }
    } else {
        cb(null, false);
    }
};

const upload = multer({ storage: storage, fileFilter: fileFilter });

// User registration route
router.post(
    '/register',
    upload.fields([{ name: 'profileImg', maxCount: 1 }, { name: 'resume', maxCount: 1 }]),
    registerUser,
);

// User login route
router.post('/login', loginUser);

// Get user route
router.get('/user/:id', getUser);

export default router;
